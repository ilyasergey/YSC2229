(*
This file is part of teaching material of Yale-NUS College module
"YSC2229: Introductory Data Structures and Algorithms"

Copyright (c) 2020 Ilya Sergey

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE.
*)

open Util
open Allocator
open DoublyLinkedList
open Queue

(******************************************************)
(*             Testing heap queue                     *)
(******************************************************)

open AllocatorImpl
module Q = HeapDLLQueue(AllocatorImpl)

open Q

open ArrayUtil

let%test "basic queue operations" = 
  let q = mk_queue 10 in
  enqueue q (42, "a");
  let e = dequeue q in
  e = Some (42, "a")

let%test "empty?" = 
  let q = mk_queue 10 in
  enqueue q (42, "a");
  let _ = dequeue q in
  is_empty q

let%test "full?" = 
  let q = mk_queue 1 in
  enqueue q (42, "a");
  let _ = dequeue q in
  not (is_full q)

let%test "queue_to_list?" =
  let x = generate_key_value_array 100 in
  let q = mk_queue 100  in
  for i = 0 to 99 do
    enqueue q x.(i)
  done;
  let l = queue_to_list q in
  array_to_list x = l
 
(******************************************************)
(*         Testing heap reclamation                   *)
(******************************************************)

(*

Implement a test that creates a small heap, and then uses it to 
allocate and use a queue (by enqueueing and dequeueing), in a way 
that the number of nodes the queue has over its lifetime is *larger*
than the capacity of the heap. That is, make sure to use memory 
reclamation implemented for doubly-linked lists.

*)

let%test "to the max!" =
  let x = generate_key_value_array 100 in
  let y = generate_key_value_array 100 in
  let q = mk_queue 100  in
  for i = 0 to 99 do
    enqueue q x.(i)
  done;
  let l1' = queue_to_list q in
  let l1 = array_to_list x in
  for i = 0 to 99 do
    let _ = dequeue q in
    enqueue q y.(i)
  done;
  let l2' = queue_to_list q in
  let l2 = array_to_list y in
  l1' = l1 && l2' = l2
    

