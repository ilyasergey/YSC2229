(*
This file is part of teaching material of Yale-NUS College module
"YSC2229: Introductory Data Structures and Algorithms"

Copyright (c) 2020 Ilya Sergey

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*)

open Allocator
open Util
open AllocatorImpl

(**********************************************)
(*              Testing allocator             *)
(**********************************************)

let%test "int ptr preservation" = 
  let open AllocatorImpl in
  let hp = make_heap 1000 in
  let ptr = alloc hp 2 in
  assign_int hp ptr 0 42;
  assign_int hp ptr 1 12;
  let res1 = deref_as_int hp ptr 0 in
  let res2 = deref_as_int hp ptr 1 in
  res1 = 42 && res2 = 12

let%test "str ptr preservation" = 
  let open AllocatorImpl in
  let hp = make_heap 1000 in
  let ptr = alloc hp 2 in
  assign_string hp ptr 0 "yo";
  assign_string hp ptr 1 "watup";
  let res1 = deref_as_string hp ptr 0 in
  let res2 = deref_as_string hp ptr 1 in
  res1 = "yo" && res2 = "watup"

let%test "ptr ptr preservation" = 
  let open AllocatorImpl in
  let hp = make_heap 1000 in
  let ptr = alloc hp 2 in
  let ptr2 = alloc hp 3 in
  assign_ptr hp ptr 0 ptr;
  assign_ptr hp ptr 1 ptr2;
  let res1 = deref_as_ptr hp ptr 0 in
  let res2 = deref_as_ptr hp ptr 1 in
  res1 = ptr && res2 = ptr2

  
let%test "testnull" = 
  let open AllocatorImpl in
  let hp = make_heap 10 in
  is_null hp (null hp)

