(*
This file is part of teaching material of Yale-NUS College module
"YSC2229: Introductory Data Structures and Algorithms"

Copyright (c) 2020 Ilya Sergey

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE.
*)

open Util
open Allocator
open DoublyLinkedList
open Queue

(******************************************************)
(*             Testing heap queue                     *)
(******************************************************)

open AllocatorImpl
module Q = HeapDLLQueue(AllocatorImpl)

open Q

let%test "basic queue operations" = 
  let q = mk_queue 10 in
  enqueue q (42, "a");
  let e = dequeue q in
  e = Some (42, "a")

let%test "enqueue dequeue empty" =
  let q = mk_queue 1 in
  enqueue q (33, "abc");
  let res1 = dequeue q in
  is_empty q && res1 = Some (33, "abc")

let%test "emptied queue returns None" =
  let q = mk_queue 4 in
  enqueue q (1, "a");
  enqueue q (2, "b");
  enqueue q (3, "c");
  let res1 = dequeue q in
  let res2 = dequeue q in
  let res3 = dequeue q in
  let res4 = dequeue q in
  is_empty q && res1 = Some (1, "a") && res2 = Some (2, "b") && res3 = Some (3, "c") && res4 = None

let%test "queue follows FIFO" = 
  let q = mk_queue 20 in
  enqueue q (42, "a");
  enqueue q (15, "b");
  enqueue q (33, "c");
  let e1 = dequeue q in
  let e2 = dequeue q in
  let e3 = dequeue q in
  e1 = Some (42, "a") &&
  e2 = Some (15, "b") &&
  e3 = Some (33, "c")

let%test "queue-to-list" =
  let q = mk_queue 20 in
  enqueue q (42, "a");
  enqueue q (15, "b");
  enqueue q (33, "c");
  let res = queue_to_list q in
  res = [(42, "a"); (15, "b"); (33, "c")]


(******************************************************)
(*         Testing heap reclamation                   *)
(******************************************************)

(*

Implement a test that creates a small heap, and then uses it to 
allocate and use a queue (by enqueueing and dequeueing), in a way 
that the number of nodes the queue has over its lifetime is *larger*
than the capacity of the heap. That is, make sure to use memory 
reclamation implemented for doubly-linked lists.

*)

let%test "heap reclamation" = 
  let q = mk_queue 5 in
  enqueue q (42, "a");
  enqueue q (15, "b");
  enqueue q (33, "c");
  enqueue q (52, "d");
  enqueue q (31, "e");
  let e1 = dequeue q in
  let e2 = dequeue q in
  let e3 = dequeue q in
  enqueue q (300, "new");
  enqueue q (235, "alloced");
  e1 = Some (42, "a") &&
  e2 = Some (15, "b") &&
  e3 = Some (33, "c")
