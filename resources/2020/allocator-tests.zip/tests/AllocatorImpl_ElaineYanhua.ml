open Allocator
open AllocatorImpl

(************************************************)
(*              Elaine-Yanhua                   *)
(************************************************)

(* ============== NULL PTR  ================*)

let%test "null ptr is null" =
  let open AllocatorImpl in
  let hp = make_heap 1000 in
  let nullptr = null hp in
  is_null hp nullptr

(* =========== PTR PRESERVATION =============*)


let%test "int ptr preservation" =
  let open AllocatorImpl in
  let hp = make_heap 1000 in
  let ptr = alloc hp 2 in
  assign_int hp ptr 0 42;
  assign_int hp ptr 1 12;
  let res1 = deref_as_int hp ptr 0 in
  let res2 = deref_as_int hp ptr 1 in
  res1 = 42 && res2 = 12

let%test "int string ptr preservation" =
  let open AllocatorImpl in
  let hp = make_heap 1000 in
  let ptr = alloc hp 2 in
  assign_int hp ptr 0 42;
  assign_string hp ptr 1 "ab";
  let res1 = deref_as_int hp ptr 0 in
  let res2 = deref_as_string hp ptr 1 in
  res1 = 42 && res2 = "ab"

let%test "ptr string ptr preservation" =
  let open AllocatorImpl in
  let hp = make_heap 1000 in
  let ptr_to_ptr = alloc hp 2 in
  let ptr = alloc hp 5 in 
  assign_ptr hp ptr_to_ptr 0 ptr;
  assign_string hp ptr 1 "ab";
  assign_int hp ptr 0 5;
  let res1 = deref_as_int hp (deref_as_ptr hp ptr_to_ptr 0) 0 in
  let res2 = deref_as_string hp ptr 1 in
  res1 = 5 && res2 = "ab"

let%test "update string pointer" =
  let open AllocatorImpl in
  let hp = make_heap 1000 in
  let ptr = alloc hp 2 in
  assign_string hp ptr 0 "abc";
  assign_string hp ptr 1 "def";
  assign_string hp ptr 0 "xyz";
  assign_string hp ptr 1 "qrs";
  let res1 = deref_as_string hp ptr 0 in
  let res2 = deref_as_string hp ptr 1 in
  res1 = "xyz" && res2 = "qrs"

let%test "string ptr preservation" =
  let open AllocatorImpl in
  let hp = make_heap 1000 in
  let ptr = alloc hp 2 in
  assign_string hp ptr 0 "hello";
  assign_string hp ptr 1 "hello again";
  let res1 = deref_as_string hp ptr 0 in
  let res2 = deref_as_string hp ptr 1 in
  res1 = "hello" && res2 = "hello again"

let%test "string ptr preservation 2" =
  let open AllocatorImpl in
  let hp = make_heap 1000 in
  let ptr = alloc hp 2 in
  assign_string hp ptr 0 "abc";
  assign_string hp ptr 1 "def";
  let res1 = deref_as_string hp ptr 0 in
  let res2 = deref_as_string hp ptr 1 in
  res1 = "abc" && res2 = "def"

let%test "ptr to ptr preservation" =
  let open AllocatorImpl in
  let hp = make_heap 1000 in
  let ptr_to_ptr = alloc hp 1 in
  let ptr_to_int = alloc hp 2 in
  assign_ptr hp ptr_to_ptr 0 ptr_to_int;
  assign_int hp ptr_to_int 0 42;
  assign_int hp ptr_to_int 1 12;
  let res1 = deref_as_int hp (deref_as_ptr hp ptr_to_ptr 0) 0 in
  let res2 = deref_as_int hp (deref_as_ptr hp ptr_to_ptr 0) 1 in
  res1 = 42 && res2 = 12

let%test "ptr to ptr preservation 2" =
  let open AllocatorImpl in
  let hp = make_heap 1000 in
  let ptr = alloc hp 2 in
  let pointer1 = alloc hp 1 in
  let pointer2 = alloc hp 1 in
  assign_int hp pointer1 0 12;
  assign_int hp pointer2 0 22;
  assign_ptr hp ptr 0 pointer1;
  assign_ptr hp ptr 1 pointer2;
  let res1 = deref_as_int hp (deref_as_ptr hp ptr 0) 0 in
  let res2 = deref_as_int hp (deref_as_ptr hp ptr 1) 0 in
  res1 = 12 && res2 = 22

(* ================ FREE =============*)

let%test "freeing up too many elements, assign values by alloc again" =
  let open AllocatorImpl in
  let hp = make_heap 10 in
  let ptr1 = alloc hp 5 in
  ignore(alloc hp 3);
  free hp ptr1 6;
  let ptr3 = alloc hp 6 in
  assign_int hp ptr3 5 80;
  let res = deref_as_int hp ptr3 5 in
  res = 80

(************************************************)
(*             Karolina-Anna                    *)
(************************************************)

let%test "str ptr preservation" = 
  let open AllocatorImpl in
  let hp = make_heap 1000 in
  let ptr = alloc hp 2 in
  assign_string hp ptr 0 "a";
  assign_string hp ptr 1 "b";
  let res1 = deref_as_string hp ptr 0 in
  let res2 = deref_as_string hp ptr 1 in
  res1 = "a" && res2 = "b"

let%test "ptr ptr preservation" = 
  let open AllocatorImpl in
  let hp = make_heap 1000 in
  let ptr = alloc hp 2 in
  let ptr1 = alloc hp 1 in
  let ptr2 = alloc hp 1 in
  assign_ptr hp ptr 0 ptr1 ;
  assign_ptr hp ptr 1 ptr2;
  let res1 = deref_as_ptr hp ptr 0 in
  let res2 = deref_as_ptr hp ptr 1 in
  res1 = ptr1 && res2 = ptr2

let%test "is_null" =
   let open AllocatorImpl in
   let hp = make_heap 10 in
   let n = null hp in
   (is_null hp n)


let%test "alloc and free" =
  let open AllocatorImpl in
  let hp = make_heap 10 in
  let ptr = alloc hp 9 in
  free hp ptr 9;
  let ptr2 = alloc hp 9 in
  assign_int hp ptr2 0 1;
  let res1 = deref_as_int hp ptr2 0 in
  res1 = 1
