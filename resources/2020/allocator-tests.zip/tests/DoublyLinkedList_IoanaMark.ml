(*
This file is part of teaching material of Yale-NUS College module
"YSC2229: Introductory Data Structures and Algorithms"

Copyright (c) 2020 Ilya Sergey

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*)

open Util
open Allocator
open DoublyLinkedList
open AllocatorImpl

(* Concrete allocator *)
module DLLImpl = DoublyLinkedList(AllocatorImpl)

open DLLImpl

let%test "basic node manipulation" = 
  let heap = AllocatorImpl.make_heap 10 in
  let n1 = mk_node heap 1 "a" 
  and n2 = mk_node heap 2 "b" in
  insert_after heap n1 n2;
  let n = next heap n1 in
  let i = int_value heap n in
  let s = string_value heap n in
  i = 2 && s = "b"

(* TODO: Add more tests. *)

let%test "basic node manipulation: check other node" = 
  let heap = AllocatorImpl.make_heap 10 in
  let n1 = mk_node heap 1 "a" 
  and n2 = mk_node heap 2 "b" in
  insert_after heap n1 n2;
  let n = prev heap n2 in
  let i = int_value heap n in
  let s = string_value heap n in
  i = 1 && s = "a"

let%test "deletion between nodes" = 
  let heap = AllocatorImpl.make_heap 12 in
  let n1 = mk_node heap 1 "a" 
  and n2 = mk_node heap 2 "b" in
  insert_after heap n1 n2;
  let n3 = mk_node heap 3 "c" in
  insert_after heap n2 n3;
  remove heap n2;
  let n = next heap n1 in
  let i = int_value heap n in
  let s = string_value heap n in
  i = 3 && s = "c"

let%test "deletion between nodes: check other node" = 
  let heap = AllocatorImpl.make_heap 12 in
  let n1 = mk_node heap 1 "a" 
  and n2 = mk_node heap 2 "b" in
  insert_after heap n1 n2;
  let n3 = mk_node heap 3 "c" in
  insert_after heap n2 n3;
  remove heap n2;
  let n = prev heap n3 in
  let i = int_value heap n in
  let s = string_value heap n in
  i = 1 && s = "a"

let%test "deletion on last node" = 
  let heap = AllocatorImpl.make_heap 12 in
  let n1 = mk_node heap 1 "a" 
  and n2 = mk_node heap 2 "b" in
  insert_after heap n1 n2;
  let n3 = mk_node heap 3 "c" in
  insert_after heap n2 n3;
  remove heap n3;
  let n = next heap n1 in
  let i = int_value heap n in
  let s = string_value heap n in
  i = 2 && s = "b"

let%test "deletion on first node" = 
  let heap = AllocatorImpl.make_heap 12 in
  let n1 = mk_node heap 1 "a" 
  and n2 = mk_node heap 2 "b" in
  let n3 = mk_node heap 3 "c" in
  insert_after heap n1 n2;
  insert_after heap n2 n3;
  remove heap n1; true (* No errors! *)
  
let%test "deletion on single node" = 
  let heap = AllocatorImpl.make_heap 12 in
  let n1 = mk_node heap 1 "a" in
  remove heap n1; true (* No errors! *)
  
let%test "delete and insert" = 
  let heap = AllocatorImpl.make_heap 12 in
  let n1 = mk_node heap 1 "a" 
  and n2 = mk_node heap 2 "b" in
  insert_after heap n1 n2;
  let n3 = mk_node heap 3 "c" in
  insert_after heap n2 n3;
  remove heap n2;
  let n4 = mk_node heap 4 "d" in
  insert_after heap n3 n4;
  let n = next heap n3 in
  let i = int_value heap n in
  let s = string_value heap n in
  let n2 = prev heap n3 in
  let i2 = int_value heap n2 in
  let s2 = string_value heap n2 in
  i = 4 && s = "d" && i2 = 1 && s2 = "a"

(* Printing tests. *)

