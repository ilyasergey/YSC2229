(*
This file is part of teaching material of Yale-NUS College module
"YSC2229: Introductory Data Structures and Algorithms"

Copyright (c) 2020 Ilya Sergey

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*)

open Allocator
open Util
open ArrayUtil
open AllocatorImpl

(**********************************************)
(*              Testing allocator             *)
(**********************************************)

let%test "int ptr preservation" = 
  let open AllocatorImpl in
  let hp = make_heap 10 in
  let ptr = alloc hp 2 in
  assign_int hp ptr 0 42;
  assign_int hp ptr 1 12;
  let res1 = deref_as_int hp ptr 0 in
  let res2 = deref_as_int hp ptr 1 in
  res1 = 42 && res2 = 12

let%test "str ptr preservation" = 
  let open AllocatorImpl in
  let hp = make_heap 10 in
  let ptr = alloc hp 2 in
  assign_string hp ptr 0 "hello";
  assign_string hp ptr 1 "world";
  let res1 = deref_as_string hp ptr 0 in
  let res2 = deref_as_string hp ptr 1 in
  res1 = "hello" && res2 = "world"

let%test "ptr ptr preservation" = 
  let open AllocatorImpl in 
  let hp = make_heap 10 in 
  let ptr = alloc hp 1 in
  let ptr2 = alloc hp 2 in
  assign_ptr hp ptr2 0 ptr;
  let res = deref_as_ptr hp ptr2 0 in
  res = ptr

let%test "different ptr preservation" =
  let open AllocatorImpl in 
  let hp = make_heap 50 in 
  let ptr = alloc hp 10 in
  let ptr2 = alloc hp 5 in
  assign_int hp ptr 0 111111;
  assign_string hp ptr 1 "this is a string";
  assign_ptr hp ptr 2 ptr2;
  assign_ptr hp ptr2 0 ptr;
  assign_int hp ptr2 1 222222;
  assign_string hp ptr2 2 "another string";
  let res1 = deref_as_int hp ptr 0 in
  let res2 = deref_as_string hp ptr 1 in
  let res3 = deref_as_ptr hp ptr 2 in
  let res4 = deref_as_ptr hp ptr2 0 in
  let res5 = deref_as_int hp ptr2 1 in
  let res6 = deref_as_string hp ptr2 2 in
  res1 = 111111 && res2 = "this is a string" && res3 = ptr2  &&
    res4 = ptr && res5 = 222222 && res6 = "another string"
  
let%test "multiple alloc operations" =
  let open AllocatorImpl in
  let hp = make_heap 50 in
  let p1 = alloc hp 4 in
  let p2 = alloc hp 6 in
  let p3 = alloc hp 8 in
  assign_int hp p1 3 123456;
  assign_string hp p2 5 "test";
  assign_int hp p3 6 812237;
  let res1 = deref_as_int hp p1 3 in
  let res2 = deref_as_string hp p2 5 in
  let res3 = deref_as_int hp p3 6 in
  res1 = 123456 && res2 = "test" && res3 = 812237
  
let%test "null operations" = 
  let open AllocatorImpl in 
  let hp = make_heap 10 in
  let null_ptr = null hp in
  is_null hp null_ptr

let%test "consecutive free and alloc operations" = 
  let open AllocatorImpl in 
  let hp = make_heap 50 in 
  let test_arr = Array.make 50 (null hp) in
  for i = 0 to 48 do (* only 49 here bc of null ptr *)
    test_arr.(i) <- alloc hp 1
  done; 
  for i = 0 to 48 do
    free hp test_arr.(i) 1 
  done;
  for i = 0 to 47 do
     test_arr.(i) <- alloc hp 1
  done;
  let a = alloc hp 1 in 
  assign_ptr hp a 0 (null hp);
  is_null hp (deref_as_ptr hp a 0)

let%test "alternating free and alloc operation" =
  let open AllocatorImpl in 
  let hp = make_heap 2 in 
  for i = 0 to 10000 do 
    let a = alloc hp 1 in 
    free hp a 1
  done; 
  let b = alloc hp 1 in 
  assign_int hp b 0 12;
  let res = deref_as_int hp b 0 in 
  res = 12

let%test "consecutive alloc operations on ptrs of different sizes" = 
  let open AllocatorImpl in 
  let hp = make_heap 1000 in 
  let test_arr = Array.make 50 (null hp) in
  for i = 1 to 30 do 
    test_arr.(i) <- alloc hp i 
  done; 
  not (is_null hp test_arr.(20))
