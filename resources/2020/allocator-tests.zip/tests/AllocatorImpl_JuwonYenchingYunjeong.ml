(*
This file is part of teaching material of Yale-NUS College module
"YSC2229: Introductory Data Structures and Algorithms"

Copyright (c) 2020 Ilya Sergey

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*)

open Allocator
open Util
open AllocatorImpl

(**********************************************)
(*              Testing allocator             *)
(**********************************************)

let%test "int ptr preservation" = 
  let open AllocatorImpl in
  let hp = make_heap 1000 in
  let ptr = alloc hp 2 in
  assign_int hp ptr 0 42;
  assign_int hp ptr 1 12;
  let res1 = deref_as_int hp ptr 0 in
  let res2 = deref_as_int hp ptr 1 in
  res1 = 42 && res2 = 12 


let%test "int str ptr preservation" = 
  let open AllocatorImpl in
  let hp = make_heap 10 in
  let ptr = alloc hp 3 in
  assign_int hp ptr 0 42;
  assign_string hp ptr 1 "a";
  assign_ptr hp ptr 2 (null hp);
  let res1 = deref_as_int hp ptr 0 in
  let res2 = deref_as_string hp ptr 1 in
  let res3 = deref_as_ptr hp ptr 2 in
  res1 = 42 && res2 = "a" && res3 = (null hp)

let%test "alloc-free-alloc" =
  let open AllocatorImpl in
  let hp = make_heap 10 in
  let ptr1 = alloc hp 4 in
  let ptr2 = alloc hp 4 in
  free hp ptr2 4;
  free hp ptr1 4;
  let ptr3 = alloc hp 4 in
  let ptr4 = alloc hp 4 in
  ptr1 = ptr3 && ptr2 = ptr4

let%test "ptr preservation" =
  let open AllocatorImpl in
  let hp = make_heap 500 in
  let null_ptr = null hp in
  let ptr1 = alloc hp 4 in
  let ptr2 = alloc hp 4 in
  assign_ptr hp ptr1 2 null_ptr;
  assign_ptr hp ptr1 3 ptr2;
  assign_ptr hp ptr2 2 ptr1;
  let ptr1_prev = deref_as_ptr hp ptr1 2 in
  let ptr1_next = deref_as_ptr hp ptr1 3 in
  let ptr2_prev = deref_as_ptr hp ptr2 2 in
  ptr1_prev = null_ptr && ptr1_next = ptr2 && ptr2_prev = ptr1

let%test "int-str-ptr preservation" =
  let open AllocatorImpl in
  let hp = make_heap 1000 in
  let null_ptr = null hp in
  let ptr1 = alloc hp 5 in
  let ptr2 = alloc hp 5 in
  let ptr3 = alloc hp 5 in
  assign_int hp ptr1 0 10; assign_string hp ptr1 1 "a"; assign_int hp ptr1 2 11;
  assign_ptr hp ptr1 3 null_ptr; assign_ptr hp ptr1 4 ptr2;
  assign_int hp ptr2 0 20; assign_string hp ptr2 1 "b"; assign_int hp ptr2 2 22;
  assign_ptr hp ptr2 3 ptr1; assign_ptr hp ptr2 4 ptr3;
  (* data from ptr1 *)
  let ptr1_int1 = deref_as_int hp ptr1 0 in
  let ptr1_str = deref_as_string hp ptr1 1 in
  let ptr1_int2 = deref_as_int hp ptr1 2 in
  let ptr1_prev = deref_as_ptr hp ptr1 3 in
  let ptr1_next = deref_as_ptr hp ptr1 4 in
  (* data from ptr2 *)
  let ptr2_int1 = deref_as_int hp ptr2 0 in
  let ptr2_str = deref_as_string hp ptr2 1 in
  let ptr2_int2 = deref_as_int hp ptr2 2 in
  let ptr2_prev = deref_as_ptr hp ptr2 3 in
  let ptr2_next = deref_as_ptr hp ptr2 4 in
  ptr1_int1 = 10 && ptr1_str = "a" && ptr1_int2 = 11 &&
  ptr2_int1 = 20 && ptr2_str = "b" && ptr2_int2 = 22 &&
  ptr1_prev = null_ptr && ptr1_next = ptr2 &&
  ptr2_prev = ptr1 && ptr2_next = ptr3 

let%test "alloc-assign-free-reclaim" =
  let open AllocatorImpl in
  let hp = make_heap 1000 in
  let null_ptr = null hp in
  let ptr1 = alloc hp 4 in
  let ptr2 = alloc hp 8 in
  let ptr3 = alloc hp 4 in
  assign_ptr hp ptr1 2 null_ptr;
  assign_ptr hp ptr1 3 ptr2;
  assign_ptr hp ptr2 2 ptr1;
  assign_ptr hp ptr2 3 ptr3;
  let ptr1_prev = deref_as_ptr hp ptr1 2 in
  let ptr1_next = deref_as_ptr hp ptr1 3 in
  let ptr2_prev = deref_as_ptr hp ptr2 2 in
  let ptr2_next = deref_as_ptr hp ptr2 3 in
  free hp ptr2 8;
  let ptr4 = alloc hp 4 in
  free hp ptr3 4;
  let ptr5 = alloc hp 4 in
  let ptr6 = alloc hp 4 in
  ptr2 = ptr4 && ptr3 = ptr6 && ptr1 <> ptr5 &&
  ptr1_prev = null_ptr && ptr1_next = ptr2 &&
  ptr2_prev = ptr1 && ptr2_next = ptr3

let%test "last-assignment-matters" =
  let open AllocatorImpl in
  let hp = make_heap 100 in
  let ptr = alloc hp 4 in
  assign_int hp ptr 1 100;
  assign_string hp ptr 1 "a";
  let assigned_value = deref_as_string hp ptr 1 in
  assigned_value = "a"

let%test "ref ref check" =
  let open AllocatorImpl in
  let h = make_heap 10 in
  let p1 = alloc h 2 in
  let p2 = alloc h 2 in
  assign_int h p1 0 2;
  assign_ptr h p2 1 p1;
  assign_int h p1 0 3;
  let i = deref_as_int h (deref_as_ptr h p2 1) 0 in
  i = 3

(* note : 3 tests below may not pass in other implementation designs *)

(*
let%test "reclamation test 1" =
  let open AllocatorImpl in
  let h = make_heap 20 in
  ignore(alloc h 2);
  let p2 = alloc h 2 in
  let p3 = alloc h 2 in
  ignore(alloc h 2);
  let p5 = alloc h 2 in
  free h p2 2;
  free h p3 2;
  free h p5 2;
  alloc h 2 = p2

let%test "reclamation test 2" =
  let open AllocatorImpl in
  let h = make_heap 20 in
  ignore(alloc h 2);
  let p2 = alloc h 2 in
  let p3 = alloc h 2 in
  ignore(alloc h 2);
  let p5 = alloc h 2 in
  ignore(alloc h 2);
  free h p2 2;
  free h p3 2;
  free h p5 2;
  alloc h 2 = p5

let%test "reclamation test 3" =
  let open AllocatorImpl in
  let h = make_heap 10000 in
  ignore(alloc h 1000);
  let p2 = alloc h 1000 in
  let p3 = alloc h 1000 in
  ignore(alloc h 1000);
  let p5 = alloc h 1000 in
  free h p2 1000;
  free h p3 1000;
  free h p5 1000;
  alloc h 1000 = p5 |> not
*)

