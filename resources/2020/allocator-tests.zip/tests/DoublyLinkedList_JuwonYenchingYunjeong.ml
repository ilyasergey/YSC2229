(*
This file is part of teaching material of Yale-NUS College module
"YSC2229: Introductory Data Structures and Algorithms"

Copyright (c) 2020 Ilya Sergey

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*)

open Util
open Allocator
open DoublyLinkedList

(**********************************************)
(*              Testing DLL                   *)
(**********************************************)

open AllocatorImpl
open AllocatorImpl

(* Concrete allocator *)
module DLLImpl = DoublyLinkedList(AllocatorImpl)

open DLLImpl

let%test "basic node manipulation" = 
  let heap = make_heap 10 in 
  let n1 = mk_node heap 1 "a" 
  and n2 = mk_node heap 2 "b" in
  insert_after heap n1 n2;
  let n = next heap n1 in
  let i = int_value heap n in
  let s = string_value heap n in
  i = 2 && s = "b"

(* below test should print [(1, a); (2, b)] *)
let%test "printing" =
  let h = make_heap 10 in
  let n1 = mk_node h 1 "a" 
  and n2 = mk_node h 2 "b" in
  insert_after h n1 n2;
  print_from_node h n1;
  true

let%test "prev-next of multiple nodes" =
  let hp = make_heap 100 in
  let n1 = mk_node hp 10 "A"
  and n2 = mk_node hp 20 "B"
  and n3 = mk_node hp 30 "C"
  and n4 = mk_node hp 40 "D" in
  insert_after hp n1 n2;
  insert_after hp n2 n3;
  insert_after hp n3 n4;
  prev hp n1 = (null hp) && next hp n1 = n2 &&
  prev hp n2 = n1 && next hp n2 = n3 &&
  prev hp n3 = n2 && next hp n3 = n4 &&
  prev hp n4 = n3 && next hp n4 = (null hp)

let%test "unlinked nodes pointing to nothing" =
  let hp = make_heap 100 in
  let n1 = mk_node hp 1 "a"
  and n2 = mk_node hp 2 "e"
  and n3 = mk_node hp 3 "i"
  and n4 = mk_node hp 4 "o"
  and n5 = mk_node hp 5 "u" in
  let nothing = null hp in
  prev hp n1 = nothing && next hp n1 = nothing &&
  prev hp n2 = nothing && next hp n2 = nothing &&
  prev hp n3 = nothing && next hp n3 = nothing &&
  prev hp n4 = nothing && next hp n4 = nothing &&
  prev hp n5 = nothing && next hp n5 = nothing

let%test "after node removal" =
  let hp = make_heap 100 in
  let n1 = mk_node hp 1 "uno"
  and n2 = mk_node hp 2 "dos"
  and n3 = mk_node hp 3 "tres" in
  insert_after hp n1 n2;
  insert_after hp n2 n3;
  remove hp n2;
  next hp n1 = n3 &&
  prev hp n3 = n1
