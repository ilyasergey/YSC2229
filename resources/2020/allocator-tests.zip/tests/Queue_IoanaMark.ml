(*
This file is part of teaching material of Yale-NUS College module
"YSC2229: Introductory Data Structures and Algorithms"

Copyright (c) 2020 Ilya Sergey

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE.
*)

open Util
open Allocator
open DoublyLinkedList
open Queue

open AllocatorImpl
module Q = HeapDLLQueue(AllocatorImpl)

open Q

let%test "basic queue operations" = 
  let q = mk_queue 10 in
  enqueue q (42, "a");
  let e = dequeue q in
  e = Some (42, "a")

(* TODO: Add more tests. *)

let%test "basic queue operations: other elem" = 
  let q = mk_queue 10 in
  enqueue q (42, "a");
  enqueue q (43, "a");
  let e = dequeue q in
  e = Some (42, "a")

let%test "empty" = 
  let q = mk_queue 10 in
  assert (is_empty q);
  enqueue q (42, "a");
  assert (not (is_empty q));
  enqueue q (43, "a");
  assert (not (is_empty q));
  let _ = dequeue q in
  assert (not (is_empty q));
  let _ = dequeue q in    
  is_empty q

let%test "not empty" = 
  let q = mk_queue 10 in
  enqueue q (42, "a");
  enqueue q (43, "a");
  let _ = dequeue q in     
  is_empty q = false
  
let%test "listify" =
  let q = mk_queue 3 in
  enqueue q (42, "a");
  enqueue q (43, "b");
  queue_to_list q = [(42, "a"); (43, "b")]

let%test "listify after dequeue" =
  let q = mk_queue 3 in
  enqueue q (42, "a");
  enqueue q (43, "b");
  enqueue q (44, "c");
  let e = dequeue q in
  let l = queue_to_list q in 
  l = [(43, "b"); (44, "c")] && e = Some (42, "a")

let%test "listify empty queue" =
  let q = mk_queue 3 in
  queue_to_list q = []

let%test "testing a queue with an array (from Prof queue impl)" =
  let open ArrayUtil in
  let q = mk_queue 10 in
  let a = generate_key_value_array 10 in
  Array.iter (fun e -> enqueue q e) a;
  queue_to_list q = array_to_list a
    
(******************************************************)
(*         Testing heap reclamation                   *)
(******************************************************)

(*
Implement a test that creates a small heap, and then uses it to 
allocate and use a queue (by enqueueing and dequeueing), in a way 
that the number of nodes the queue has over its lifetime is *larger*
than the capacity of the heap. That is, make sure to use memory 
reclamation implemented for doubly-linked lists.
*)

let%test "heap reclamation: enqueue 3 items on size 2 queue" =
  let q = mk_queue 2 in
  enqueue q (0, ":)");
  enqueue q (1, ":)");
  let res = dequeue q in
  enqueue q (2, ":)");
  res = Some (0, ":)")
  
let%test "heap reclamation: enqueue/dequeue 1000 items on size 2 queue" =
  let q = mk_queue 2 in
  enqueue q (0, ":(");
  enqueue q (1, ":(");
  let rec build q i l =
    if i = 1002 then l
    else
      begin
        let a = match dequeue q with
          | Some (k, v) -> (k, v)
          | _ -> error "Ah!"
        in
        enqueue q (i, ":(");
        build q (i + 1) (a :: l)
      end
  in
  let res = build q 2 [] in
  let rec check l i =
    match l with
    | [] -> true
    | (k, v) :: t -> if k = i && v = ":(" then check t (i - 1) else false
  in
  check res 999

