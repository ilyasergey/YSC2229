open Allocator
open AllocatorImpl

(************************************************)
(*             Karolina-Anna                    *)
(************************************************)

let%test "str ptr preservation" = 
  let open AllocatorImpl in
  let hp = make_heap 1000 in
  let ptr = alloc hp 2 in
  assign_string hp ptr 0 "a";
  assign_string hp ptr 1 "b";
  let res1 = deref_as_string hp ptr 0 in
  let res2 = deref_as_string hp ptr 1 in
  res1 = "a" && res2 = "b"

let%test "ptr ptr preservation" = 
  let open AllocatorImpl in
  let hp = make_heap 1000 in
  let ptr = alloc hp 2 in
  let ptr1 = alloc hp 1 in
  let ptr2 = alloc hp 1 in
  assign_ptr hp ptr 0 ptr1 ;
  assign_ptr hp ptr 1 ptr2;
  let res1 = deref_as_ptr hp ptr 0 in
  let res2 = deref_as_ptr hp ptr 1 in
  res1 = ptr1 && res2 = ptr2

let%test "is_null" =
   let open AllocatorImpl in
   let hp = make_heap 10 in
   let n = null hp in
   (is_null hp n)


let%test "alloc and free" =
  let open AllocatorImpl in
  let hp = make_heap 10 in
  let ptr = alloc hp 9 in
  free hp ptr 9;
  let ptr2 = alloc hp 9 in
  assign_int hp ptr2 0 1;
  let res1 = deref_as_int hp ptr2 0 in
  res1 = 1
