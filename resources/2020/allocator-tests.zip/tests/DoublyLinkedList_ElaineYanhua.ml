(*
This file is part of teaching material of Yale-NUS College module
"YSC2229: Introductory Data Structures and Algorithms"

Copyright (c) 2020 Ilya Sergey

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*)

open Util
open Allocator
open DoublyLinkedList

open AllocatorImpl

(* Concrete allocator *)
module DLLImpl = DoublyLinkedList(AllocatorImpl)

open DLLImpl

let%test "one node's values" =
  let heap = AllocatorImpl.make_heap 10 in
  let n = mk_node heap 1 "a" in
  let i = int_value heap n in
  let s = string_value heap n in
  i = 1 && s = "a"

let%test "prev and next of 1 node is null" =
  let heap = AllocatorImpl.make_heap 10 in
  let n = mk_node heap 1 "a" in
  prev heap n = (AllocatorImpl.null heap) && next heap n = (AllocatorImpl.null heap)

let%test "check for next node" =
  let heap = AllocatorImpl.make_heap 10 in
  let n1 = mk_node heap 1 "a"
  and n2 = mk_node heap 2 "b" in
  insert_after heap n1 n2;
  let n = next heap n1 in
  let i = int_value heap n in
  let s = string_value heap n in
  i = 2 && s = "b"

let%test "check for prev node" =
  let heap = AllocatorImpl.make_heap 10 in
  let n1 = mk_node heap 1 "a"
  and n2 = mk_node heap 2 "b" in
  insert_after heap n1 n2;
  let n = next heap n1 in
  let i = int_value heap (prev heap n) in
  let s = string_value heap (prev heap n) in
  i = 1 && s = "a"

let%test "prev of first and next of second is null" =
  let heap = AllocatorImpl.make_heap 10 in
  let n1 = mk_node heap 1 "a"
  and n2 = mk_node heap 2 "b" in
  insert_after heap n1 n2;
  prev heap n1 = (AllocatorImpl.null heap) && next heap n2 = (AllocatorImpl.null heap)

