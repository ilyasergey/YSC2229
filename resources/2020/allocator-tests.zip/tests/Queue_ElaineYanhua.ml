(*
This file is part of teaching material of Yale-NUS College module
"YSC2229: Introductory Data Structures and Algorithms"

Copyright (c) 2020 Ilya Sergey

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE.
*)

open Util
open ArrayUtil 
open Allocator
open DoublyLinkedList
open Queue

(******************************************************)
(*             Testing heap queue                     *)
(******************************************************)

open AllocatorImpl
module Q = HeapDLLQueue(AllocatorImpl)

open Q

let%test "empty queue" = 
  let q = mk_queue 10 in
  is_empty q

let%test "non-empty queue" = 
  let q = mk_queue 10 in
  enqueue q (42, "a");
  not (is_empty q)

let%test "dequeue empty queue" = 
  let q = mk_queue 10 in
  (dequeue q) = None

let%test "basic queue operations 1" = 
  let q = mk_queue 10 in
  enqueue q (42, "a");
  let e = dequeue q in
  e = Some (42, "a") 

let%test "basic queue operations 2" = 
  let q = mk_queue 10 in
  enqueue q (1, "a");
  enqueue q (2, "b");
  let e1 = dequeue q in
  let e2 = dequeue q in
  e1 = Some (1, "a") && e2 = Some (2, "b")

let%test "basic queue operations 3" = 
  let q = mk_queue 10 in
  enqueue q (1, "a");
  enqueue q (2, "b");
  enqueue q (3, "c");
  let e1 = dequeue q in
  let e2 = dequeue q in
  let e3 = dequeue q in
  e1 = Some (1, "a") && e2 = Some (2, "b") && e3 = Some (3, "c")

let%test "queue to list" =
  let li = array_to_list (generate_key_value_array 10) in
  let q = mk_queue 10 in
  List.iter (enqueue q) li;
  (queue_to_list q) = li

let%test "basic queue operations 4" = 
  let q = mk_queue 10 in
  enqueue q (1, "a");
  enqueue q (2, "b");
  enqueue q (3, "c");
  let e1 = dequeue q in
  let e2 = dequeue q in
  let e3 = dequeue q in
  let e4 = dequeue q in
  e1 = Some (1, "a") && e2 = Some (2, "b") && e3 = Some (3, "c") && e4 = None

let%test "basic queue operations 4" = 
  let q = mk_queue 10 in
  enqueue q (1, "a");
  enqueue q (2, "b");
  enqueue q (3, "c");
  ignore(dequeue q);
  ignore(dequeue q);
  ignore(dequeue q);
  is_empty q


(******************************************************)
(*         Testing heap reclamation                   *)
(******************************************************)

(*

Implement a test that creates a small heap, and then uses it to 
allocate and use a queue (by enqueueing and dequeueing), in a way 
that the number of nodes the queue has over its lifetime is *larger*
than the capacity of the heap. That is, make sure to use memory 
reclamation implemented for doubly-linked lists.

*)

(* Note: Enqueuing 4 nodes or more causes the out-of-memory error *)

let%test "enqueue 3, dequeue 2, enqueue 1 more" = 
  let q = mk_queue 10 in
  enqueue q (1, "a");
  enqueue q (2, "b");
  enqueue q (3, "c");
  ignore(dequeue q);
  ignore(dequeue q);
  enqueue q (1, "a");
  true

let%test "enqueue 3, dequeue 2, enqueue 2 more" = 
  let q = mk_queue 10 in
  enqueue q (1, "a");
  enqueue q (2, "b");
  enqueue q (3, "c");
  ignore(dequeue q);
  ignore(dequeue q);
  enqueue q (1, "a");
  enqueue q (2, "b");
  true

let%test "enqueue 3, dequeue 3, enqueue 1 more" = 
  let q = mk_queue 10 in
  enqueue q (1, "a");
  enqueue q (2, "b");
  enqueue q (3, "c");
  ignore(dequeue q);
  ignore(dequeue q);
  ignore(dequeue q);
  enqueue q (1, "a");
  true


let%test "enqueue 3, dequeue 3, enqueue 3, dequeue 3, enqueue 3" = 
  let q = mk_queue 3 in
  enqueue q (1, "a");
  enqueue q (2, "b");
  enqueue q (3, "c");
  ignore(dequeue q);
  ignore(dequeue q);
  ignore(dequeue q);
  enqueue q (1, "a");
  enqueue q (2, "b");
  enqueue q (3, "c");
  ignore(dequeue q);
  ignore(dequeue q);
  ignore(dequeue q);
  enqueue q (1, "a");
  enqueue q (2, "b");
  enqueue q (3, "c");
  true

let%test "testing making queue with a random array" = 
  let q = mk_queue 10 in
  let a = generate_key_value_array 10 in
  Array.iter (fun e -> enqueue q e) a;
  queue_to_list q = array_to_list a

let%test "testing queue with array, emptying it, and enqueuing another array" = 
  let q = mk_queue 10 in
  let a = generate_key_value_array 10 in
  let b = generate_key_value_array 10 in
  Array.iter (fun e -> enqueue q e) a;
  for i = 0 to 10 do
    ignore(dequeue q)
  done;
  Array.iter (fun e -> enqueue q e) b;
  queue_to_list q = array_to_list b

let%test "testing queue with array, emptying it, and enqueuing another array" = 
  let q = mk_queue 10 in
  let a = generate_key_value_array 10 in
  let b = generate_key_value_array 10 in
  Array.iter (fun e -> enqueue q e) a;
  for i = 0 to 10 do
    ignore(dequeue q)
  done;
  Array.iter (fun e -> enqueue q e) b;
  queue_to_list q = array_to_list b

let%test "testing queue with array, emptying it halfway, and enqueuing another array" = 
  let q = mk_queue 10 in
  let a = generate_key_value_array 10 in
  let b = generate_key_value_array 5 in
  Array.iter (fun e -> enqueue q e) a;
  for i = 0 to 4 do
    ignore(dequeue q)
  done;
  Array.iter (fun e -> enqueue q e) b;
  queue_to_list q =  (subarray_to_list 5 10 a) @ (array_to_list b)
