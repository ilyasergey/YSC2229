(*
This file is part of teaching material of Yale-NUS College module
"YSC2229: Introductory Data Structures and Algorithms"

Copyright (c) 2020 Ilya Sergey

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE. 
*)

open Util
open Allocator
open DoublyLinkedList
open Queue

(******************************************************)
(*             Testing heap queue                     *)
(******************************************************)

open AllocatorImpl
module Q = HeapDLLQueue(AllocatorImpl)
open Q

let%test "basic queue operations" = 
  let q = mk_queue 10 in
  enqueue q (42, "a");
  let e = dequeue q in
  e = Some (42, "a")

let%test "null test" = 
  let q = mk_queue 10 in
  is_empty q = true

(* Commenting out as contradicting is_full semantics
let%test "full test" = 
  let q = mk_queue 3 in
  enqueue q (42, "a");
  enqueue q (32, "b");
  enqueue q (22, "c");
  is_full q = true
*)

let%test "multiple queueing and dequeuing" =
  let open ArrayUtil in
  let q = mk_queue 100 in
  let kv_array = generate_key_value_array 100 in
  for i = 0 to 99 do
    enqueue q kv_array.(i)
  done;
  let rec dequeue_check i pass =
    if i >= 100 then pass
    else let res = dequeue q = Some kv_array.(i) in
         dequeue_check (i + 1) (res && pass)
  in dequeue_check 0 true
    
 
let%test "alternating queueing and dequeuing" =
  let open ArrayUtil in
  let q = mk_queue 100 in
  let kv_array = generate_key_value_array 100 in
  let rec dequeue_check i pass =
    if i >= 100 then pass
    else (enqueue q kv_array.(i);
          let res = dequeue q = Some kv_array.(i) in
          dequeue_check (i + 1) (res && pass))
  in dequeue_check 0 true 

 

(******************************************************)
(*         Testing heap reclamation                   *)
(******************************************************)

(*

Implement a test that creates a small heap, and then uses it to 
allocate and use a queue (by enqueueing and dequeueing), in a way 
that the number of nodes the queue has over its lifetime is *larger*
than the capacity of the heap. That is, make sure to use memory 
reclamation implemented for doubly-linked lists.

*)

let%test "basic reclamation test" = 
  let q = mk_queue 3 in
  enqueue q (42, "a");
  enqueue q (32, "b");
  enqueue q (22, "c");
  let a = dequeue q in 
  let b = dequeue q in 
  let c = dequeue q in
  enqueue q (12, "a");
  enqueue q (22, "b");
  enqueue q (32, "c");
  let e = dequeue q in 
  e = Some (12, "a") && 
  a = Some (42, "a") &&
  b = Some (32, "b") &&
  c = Some (22, "c") 

(* These do not correspond to the semantics for the is_full


let%test "random reclamation test" = 
  let open ArrayUtil in
  let q = mk_queue 50 in
  let kvs =  list_zip (generate_keys 100 100) (generate_words 5 100) in 
  begin
  for i = 0 to 49 do 
    enqueue q (List.nth kvs i)
  done;
  for i = 0 to 49 do
      let a = dequeue q in 
      match a with 
        | Some (k,v) -> ()
        | _ -> ()
  done;
  for i = 50 to 99 do
    enqueue q (List.nth kvs i)
  done;
  is_full q
  end


let%test "alternating random reclamation test" = 
  let open ArrayUtil in
  let q = mk_queue 1 in
  let kvs =  list_zip (generate_keys 10000 10000) (generate_words 5 10000) in 
  begin
  for i = 0 to 9999 do
    if not (i mod 2 = 0) then 
      enqueue q (List.nth kvs i)
    else 
      let a = dequeue q in 
      match a with 
        | Some (k,v) -> ()
        | _ -> ()
  done;
  is_full q
  end

*)