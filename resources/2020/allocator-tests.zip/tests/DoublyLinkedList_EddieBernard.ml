(*
This file is part of teaching material of Yale-NUS College module
"YSC2229: Introductory Data Structures and Algorithms"

Copyright (c) 2020 Ilya Sergey

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*) 

open Util
open Allocator
open DoublyLinkedList

(**********************************************)
(*              Testing DLL                   *)
(**********************************************)

open AllocatorImpl

(* Concrete allocator *)
module DLLImpl = DoublyLinkedList(AllocatorImpl)

open DLLImpl

let%test "basic node manipulation" = 
  let heap = AllocatorImpl.make_heap 100 in
  let n1 = mk_node heap 1 "a" 
  and n2 = mk_node heap 2 "b" in
  insert_after heap n1 n2;
  let n = next heap n1 in
  let i = int_value heap n in
  let s = string_value heap n in
  i = 2 && s = "b"

let%test "basic node removal" =
  let heap = AllocatorImpl.make_heap 100 in
  let n1 = mk_node heap 1 "a" 
  and n2 = mk_node heap 2 "b"
  and n3 = mk_node heap 3 "c" in 
  insert_after heap n1 n2;
  insert_after heap n2 n3;
  remove heap n2; 
  let n = next heap n1 in 
  let i = int_value heap n in
  let s = string_value heap n in
  i = 3 && s = "c"

let%test "random node addition and removal" = 
  let open ArrayUtil in 
  let int_list = generate_keys 1000 1000 in 
  let str_list = generate_words 2 1000 in
  let heap = AllocatorImpl.make_heap 4000 in
  let test_arr = Array.make 998 (AllocatorImpl.null heap) in
  let n1 = mk_node heap 1 "a" in (* Initialising *)
  let n2 = mk_node heap 2 "b" in
  insert_after heap n1 n2;
  for i = 1 to 499 do 
    let n3 = prev heap n2 in (* Store prev n2 *)
    let n1 = mk_node heap (List.nth int_list i) (List.nth str_list i) in
    let n2 = mk_node heap (List.nth int_list (i + 2)) (List.nth str_list (i + 2)) in 
    test_arr.(i - 1) <- n1;
    test_arr.(i + 1) <- n2;
    insert_after heap n3 n1; (* Link prev n2 to current n1 *)
    insert_after heap n1 n2
  done;
  let random_index = Random.int 998 in 
  let r1 = test_arr.(random_index) in (* Pick a random node *)
  let r1_prev = prev heap r1 in 
  let r1_next = next heap r1 in 
  let i = int_value heap r1_next in
  let s = string_value heap r1_next in 
  remove heap r1; 
  (* After removing r1, its old prev node should now point to its old next node *)
  (int_value heap (next heap r1_prev) = i) && (string_value heap (next heap r1_prev) = s)
